# PatientTriage.ai — Business Proposal

**Accenture Innovation Challenge 2026**

---

## 1. Problem framing

Emergency departments triage patients using the Emergency Severity Index (ESI), a five-level scale assigned by a single nurse from a 60–90 second visual and verbal assessment, typically before a full set of vitals exists. Published audits consistently find ESI mis-assignment in roughly 10–20% of cases. The costliest failure mode is under-triage — a genuinely critical patient assessed as stable — which is linked to preventable deterioration and death in the waiting room, alongside rising left-without-being-seen (LWBS) rates.

A second, less-discussed gap compounds this: once a patient is triaged, there is typically no structured mechanism to detect whether their condition changes while they wait. A patient can decline for thirty to forty minutes in a crowded waiting room before anyone notices.

Both gaps are structural, not a matter of individual clinician skill: triage reasoning isn't logged or standardized across nurses and shifts, and nothing in the current process revisits a decision once it's made.

## 2. Solution design

PatientTriage.ai addresses both gaps as a layered decision-support system:

1. **Structured intake** (FAST stroke screen, chief complaint, pain assessment, vitals) does the primary categorization — deliberately not the AI, since this is the highest-leverage, lowest-risk place to standardize practice. Two live, deterministic clinical scores — NEWS2 and qSOFA — are computed from published formulas as vitals are entered, independent of any AI call. Pain is captured via a standard self-reported 0–10 rating, or, for patients who cannot self-report (infants, unconscious, cognitively impaired), the published FLACC observational scale.
2. **A deterministic rule engine** auto-escalates unambiguous red flags (critical SpO₂, GCS, active seizure, anaphylaxis) directly to the resuscitation team, bypassing the AI layer entirely — because these rare, catastrophic cases warrant fixed, auditable logic rather than a probabilistic model. A manual "Resus Auto-Trigger Override" gives the nurse the same one-tap escalation for cases their clinical judgment catches that the form doesn't.
3. **AI-assisted acuity scoring** reads vitals and the patient's free-text complaint together, returning an ESI-style recommendation with an explanation of its top contributing factors — advisory only, never authoritative. A "Surge Mode" toggle switches every patient to the fast deterministic path during mass-casualty or high-volume conditions, when a per-patient AI call doesn't scale.
4. **Confidence Fusion** — the nurse rates their own confidence alongside the AI's; when both are low simultaneously, the case is automatically routed to a physician for a brief review, rather than being resolved by either party alone.
5. **Ambient Sentinel** — reuses hospitals' existing waiting-room CCTV and microphones to continuously monitor for a *change* in a patient's condition relative to their own baseline (breathing rate, posture, distress sounds), flagging it for nurse verification. It is explicitly a change-detector, not a diagnostic tool, and requires no new hardware.
6. **Patient identity, history, and bed management** — a photo and identity document captured at intake attach to the patient's record, feeding a searchable Patient Records view that persists across the visit, including after discharge, so identity and outcome history is retained rather than lost the moment a bed is freed. A live Bed Board tracks real occupancy and attributes each admission to the nurse who performed it, closing two operational gaps: not knowing which beds are free, and not knowing who admitted whom.

Throughout, the design principle is consistent: the system is authoritative only where a decision is deterministic and auditable (the rule engine, NEWS2, qSOFA); everywhere probabilistic reasoning is involved, it recommends, and a clinician decides. The product is also deliberately white-labeled — no AI vendor or model name appears anywhere in the interface — the way a real hospital would expect to deploy one unified clinical product rather than a wrapper around a named third-party model.

## 3. Target users

| User | How they interact with the system |
|---|---|
| **Triage nurses** | Primary daily users — review AI recommendations, confirm/override, respond to Sentinel alerts, capture patient identity, manage bed assignment |
| **Emergency physicians** | Receive Confidence Fusion escalations for a fast second opinion |
| **ED charge nurses / shift leads** | Monitor the live queue, Bed Board occupancy, and overall department load |
| **Hospital clinical governance / quality committees** | Own model validation, shadow-mode sign-off, and ongoing bias/outcome auditing |
| **Hospital IT / biomedical engineering** | Own the technical integration (EHR, CCTV feed access, edge inference infrastructure) |
| **Privacy / compliance officers** | Own retention policy, encryption, and access control for captured patient photos and identity documents |
| **Patients** | Indirect beneficiaries — faster, more consistent triage and continuous monitoring while waiting |

## 4. Business case and impact

**Cost structure favors adoption.** The largest and most novel component, Ambient Sentinel, is designed to run on infrastructure hospitals already own (existing security CCTV and microphones), which keeps the marginal hardware cost near zero per additional site — the primary cost is software integration and edge compute, not procurement of new sensors or wearables.

**Value drivers:**
- Reduction in under-triage of critical (ESI 1–2) patients — the failure mode most directly tied to preventable adverse outcomes and liability exposure.
- Reduction in undetected in-waiting-room deterioration, a recurring root cause in ED sentinel-event reviews.
- Reduced LWBS rate, as more consistent and faster triage reduces perceived and actual wait times for genuinely urgent cases.
- Standardized, auditable triage reasoning across nurses and shifts, supporting quality review and staff training — now with per-nurse admission attribution for accountability and workload visibility.
- Nurse cognitive-load reduction during high-volume or understaffed shifts, where under-triage risk is highest.
- Real-time bed visibility removes a common, low-tech point of friction — not knowing a bed is free — that otherwise adds avoidable delay between triage and treatment.
- A persistent, searchable patient record (identity, history, admitting nurse) reduces duplicate registration and improves continuity when the same patient re-presents.

**Who pays, and why they would:** hospital systems bear both the clinical risk and the liability exposure of triage errors, making the ED itself the natural buyer; the case is strengthened by the low incremental hardware cost relative to alternatives like wearable-based monitoring, which requires per-patient equipment, charging, and cleaning logistics that Ambient Sentinel avoids entirely.

## 5. Phased roadmap

| Phase | Scope | Gate to next phase |
|---|---|---|
| **0. Prototype (current)** | Structured intake with live NEWS2/qSOFA, rule engine, AI scoring with offline fallback, Confidence Fusion, simulated and camera-based Sentinel workflow, patient identity capture, Patient Records, Bed Board | Working demo validated internally |
| **1. Shadow-mode pilot** | Deploy scoring stack in one ED, logging recommendations alongside real nurse decisions with no workflow change | Score accuracy validated against real outcomes over a defined pilot window |
| **2. Advisory-only live use** | Nurses see and can act on AI recommendations; Confidence Fusion active; Bed Board and Patient Records live; Sentinel still off | Adoption and override-rate data show clinician trust and no workflow disruption |
| **3. Ambient Sentinel opt-in pilot** | Enable Sentinel in one zone with clear signage, no facial recognition, edge-only processing; identity-capture data handling reviewed and signed off by privacy/compliance | False-positive/negative alert rates within acceptable clinical bounds, and privacy review passed |
| **4. Hospital-wide scale** | Full deployment across all ED zones and shifts, including encrypted, access-controlled backend storage for identity data and bed/ADT system integration | Sustained outcome metrics (below) hold across volume and staffing conditions |
| **5. Multi-site expansion** | Deploy to additional hospitals within a health system | Phase 1–4 playbook repeatable with bounded onboarding effort per site |

## 6. Key risks and mitigations

| Risk | Mitigation |
|---|---|
| **Automation bias** — nurses over-trust AI recommendations | Explainable output (drivers + rationale, not a bare score); Confidence Fusion specifically targets joint uncertainty rather than assuming the AI is right when the nurse is unsure |
| **Alert fatigue** from Ambient Sentinel | Conservative detection thresholds at launch, tuned against real outcome data before sensitivity is increased; every alert requires human verification before any action |
| **Privacy and consent concerns** around continuous camera monitoring | No facial recognition; movement/audio-derived signals only, processed at the edge; aggregate signals retained, not raw video; visible signage and an opt-out process aligned to hospital policy |
| **Patient identity data exposure** (photos, ID documents captured at intake) | Production requires encryption at rest, role-based access control, audit logging, and a defined retention policy before go-live; the prototype explicitly discloses that it holds this data unencrypted, in-browser memory only, and never as a production reference |
| **Algorithmic bias** (e.g., under-triage disparities by race, language, or insurance status echoing known historical patterns in ED data) | Continuous bias auditing of model outputs against protected/proxy attributes; shadow-mode validation before any model update ships |
| **Regulatory classification** (clinical decision support software) | Clinical governance sign-off, model-card-style documentation, and validation practices aligned to relevant medical-device software guidance before advisory-use rollout |
| **Over-reliance during network/AI outages** | Deterministic offline heuristic fallback, and NEWS2/qSOFA computed independently of any AI call, ensure the scoring layer remains usable without connectivity to the AI service |
| **Identity documentation excluding undocumented or unhoused patients** | ID capture is always optional and never gates triage, treatment, or bed assignment — it supplements, not replaces, the clinical workflow |
| **Integration risk with legacy hospital IT (EHR, CCTV, ADT/bed-management systems)** | Phased rollout isolates integration risk to one site and one system at a time before multi-site scale |

## 7. Summary

PatientTriage.ai is designed around a simple discipline: automate only what can be made deterministic and auditable, assist everywhere else, and close the specific, under-addressed gap of unmonitored deterioration after triage — using infrastructure hospitals already have. The phased rollout and explicit risk mitigations are intended to make this a credible clinical deployment path, not only a hackathon concept.

---

**Team:** mawandiaarchit
**Challenge:** Accenture Innovation Challenge 2026 — Problem Statement 2
