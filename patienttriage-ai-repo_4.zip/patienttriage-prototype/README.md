# PatientTriage.ai

PatientTriage.ai is a working prototype of an AI-assisted decision-support
layer for emergency department triage. It is built around two ideas most
triage tools don't address: getting the first categorization right, and
never stopping the watch once a patient sits down in the waiting room.

For the full business case, target users, rollout plan, and risk analysis,
see the [Business Proposal](docs/BUSINESS_PROPOSAL.md). Known gaps and
open questions are tracked in the [Known limitations](#known-limitations)
section of this document rather than a separate issue queue.


## Table of contents

- Requirements
- Recommended setup
- Installation
- Configuration
- Problem this project addresses
- Solution overview
- How the AI and ML models work
- Architecture and path to production
- Scalability
- Impact
- Troubleshooting and FAQ
- Known limitations
- Repository structure
- Maintainers


## Requirements

This prototype requires no installation outside a modern web browser
(Chrome, Firefox, Edge, or Safari). There is no server, no build step,
and no external service that must be running for the core intake and
triage workflow to work.

Two features have additional, optional requirements:

- Live AI-assisted scoring and visual analysis require network access
  to the AI service and, when run standalone, an access key (see
  [Configuration](#configuration)).
- The camera-based Ambient Sentinel mode and the patient photo/ID
  capture fields require the browser to be granted camera and/or file
  access permission.

If neither is available, the prototype remains fully usable: it falls
back automatically to an offline deterministic scoring path, described
in [How the AI and ML models work](#how-the-ai-and-ml-models-work).


## Recommended setup

These are not required, but they unlock the full functionality of the
prototype:

- An access key for the AI service, entered under Settings, enables
  live AI-assisted acuity scoring and camera-based visual analysis when
  running the file outside a sandboxed preview. Without a key, these
  features fall back to a deterministic offline scorer and a manual
  "Quick simulate" path.
- A device camera enables the optional camera-based Ambient Sentinel
  analysis and lets the Patient Identity section capture a real photo
  at intake, rather than relying on file upload alone.


## Installation

This is a single, self-contained HTML file with no build step. Download
`index.html` and open it directly in a browser. See
[Repository structure](#repository-structure) below for what else is
included in this project.


## Configuration

1. Open Settings from the top navigation and, if running the file
   standalone, enter an access key to enable live AI-assisted scoring
   and visual analysis in place of the offline fallback.
1. Open Nurse Duty Profile to set the on-duty nurse's name. Every
   patient admitted afterward is attributed to that name, visible in
   the queue, the Bed Board, and Patient Records.
1. Toggle Surge Mode in the top navigation to switch scoring to the
   fast, deterministic rule engine for every patient, skipping the AI
   call entirely — intended for mass-casualty or high-volume
   conditions.
1. Manage bed capacity from the Bed Board, reached via the
   "Beds: N/M" indicator, using "+ Add" and "- Remove empty".

The prototype has no persistent configuration: settings, the on-duty
nurse name, and all patient data exist only in the current browser
tab's memory and reset on refresh.


## Problem this project addresses

A triage nurse has roughly 60-90 seconds to assign an Emergency
Severity Index (ESI) level to an incoming patient. Published audits
find 10-20% of these assignments are inaccurate, and the costliest
failure mode is under-triage: a genuinely critical patient judged
stable. Just as importantly, once a patient is triaged and seated in
the waiting room, almost nothing monitors whether their condition
changes before they're called.


## Solution overview

PatientTriage.ai is a layered decision-support system, not a single
model. Each layer exists to catch a specific, different kind of
failure:

| Layer | Purpose | Decides or recommends? |
|---|---|---|
| Structured intake | The actual first-pass categorization (FAST stroke screen, chief complaint, pain assessment, vitals) | Drives the initial score |
| Deterministic rule engine | Catches unambiguous, life-threatening red flags | Decides - auto-escalates, no AI in this path |
| AI acuity scoring | Reads vitals and free-text complaint, produces an explainable ESI-style recommendation | Recommends only |
| Confidence Fusion | Routes a case to a physician when both the nurse and the model are uncertain | Routes, doesn't decide |
| Ambient Sentinel | Continuously watches the waiting room for a change from a patient's own baseline | Flags for a nurse to verify - never auto-diagnoses |

This split matters: the only component that ever acts unilaterally is
the deterministic rule engine, precisely because it is auditable and
its logic is fixed and inspectable. Everything probabilistic - the AI
score, the ambient signals - stays advisory, and a human clinician
always makes the final call.

No AI vendor branding appears anywhere in the app's user interface, by
design. Buttons and labels read "Run Acuity Assessment," "AI-assisted
assessment," "Enable camera-based analysis," and "AI Service Access" in
Settings - never a specific vendor or model name. This README continues
to name the actual technology accurately, because that is honest
technical disclosure of what is implemented; the app itself is
white-labeled deliberately, the way a real hospital deployment would
present one unified clinical product rather than surfacing which
third-party model sits underneath it.

Key features implemented in this prototype:

- A three-panel enterprise dashboard (Structured Intake, Decision
  Support and Confidence Fusion, Ambient Sentinel and Dynamic Queue),
  styled in the visual language of clinical systems such as Epic
  Hyperspace or Cerner, with full light and dark mode support.
- A patient intake form covering demographics, arrival mode with
  conditional EMS pre-arrival fields, the FAST stroke screen with time
  of onset, chief complaint with a simulated voice-to-text control,
  allergy and pregnancy flags, and vitals.
- Live-updating NEWS2 and qSOFA scores, computed client-side from real
  published clinical formulas as vitals are typed, not just displayed
  after submission.
- Two pain-assessment modes: a standard self-reported 0-10 rating, and
  a "Patient can't self-report" toggle that switches to the FLACC
  scale (Face, Legs, Activity, Cry, Consolability) for infants,
  nonverbal, unconscious, or cognitively impaired patients. Whichever
  mode was used is recorded against the patient and shown wherever
  pain appears.
- A Patient Identity and History Record section that captures a
  patient photo and an identity document (type, reference number, and
  a document photo) at intake, attached to the patient's record.
- Patient Records: a searchable, permanent record of every patient
  admitted during the session, including discharged ones, showing
  photo, ESI, admitting nurse, ID type, and arrival/discharge times.
- A Decision Support panel showing the calculated ESI level, a
  SHAP-style explainability breakdown with percentage-weighted driver
  bars, and the Confidence Fusion module: a segmented nurse-certainty
  toggle that, combined with low model confidence, surfaces an
  auto-routing banner to physician review.
- One-tap actions: Confirm and Assign ESI, Override ESI, and
  Auto-Escalate to Resus Team, a manual nurse override independent of
  the calculated score.
- An Ambient Sentinel panel with a simulated waiting-room monitor,
  four live metric gauges, a real-time alert banner, and a "Simulate
  Sentinel Deterioration Alert" control that deliberately targets the
  longest-waiting, least-urgent patient - the exact scenario this
  feature exists to catch. An optional camera-based analysis mode
  sends a real frame for visual analysis every 20 seconds.
- A Dynamic Queue that re-sorts on every alert, and a Bed Board that
  tracks real bed occupancy, including which nurse admitted the
  patient currently in each bed.


## How the AI and ML models work

It is important to be precise here, because there are two different
things going on: what this browser prototype uses (fast to build, good
for demonstrating the interaction pattern), and what a real clinical
deployment would use (validated, purpose-built models). Conflating the
two would overstate what is implemented.

What the prototype actually uses today is prompted large-language-model
inference, not a trained classifier:

- Acuity scoring and photo/frame analysis both work by sending
  structured data, or an image, to a large language/vision model, with
  a tightly constrained prompt that forces a structured response. This
  is in-context reasoning, not a model trained on labeled triage
  outcomes. Its strength is reasoning jointly over free text and
  structured fields with no training data of our own required, and
  returning an explanation alongside the score. Its weakness is that
  it has not been validated against real emergency department
  outcomes, and its behavior is governed by prompt design rather than
  a measurable, fixed decision boundary.
- NEWS2 and qSOFA, by contrast, are real, deterministic clinical
  scoring formulas, not machine learning, implemented directly from
  their published point thresholds for respiratory rate, oxygen
  saturation, temperature, systolic blood pressure, heart rate, and
  consciousness. These run live and client-side, independent of any AI
  call, and are among the few parts of this prototype that would carry
  over to production essentially unchanged.
- The offline fallback scorer is not machine learning at all - it is a
  deterministic, hand-written rule scorer that folds in the NEWS2 band
  alongside FAST, pain, and vitals thresholds. Its confidence output is
  a formula based on how much structured data was available and how
  many rules fired, not a statistical model's calibrated confidence.

What a production system should use instead, per hospital, per the
phased rollout in the Business Proposal:

- Structured and tabular scoring: a gradient-boosted decision tree
  model, such as XGBoost or LightGBM, trained on historical triage
  records labeled with actual downstream outcomes. This is the
  standard, well-validated approach for structured clinical risk
  scoring, and is interpretable via SHAP feature attribution - which
  is exactly what would generate the "top drivers" shown to the nurse.
- Free-text scoring: a fine-tuned clinical language model mapped to
  symptom and severity categories, fused as an additional feature into
  the structured model rather than run as a separate score.
- Ambient Sentinel vision: not a general vision-language model run
  continuously, which would be too costly and too slow at hospital
  scale. Production would use narrow, purpose-built models: pose
  estimation for posture and slumping detection, video-magnification
  techniques for respiratory-rate-from-motion estimation, and a
  lightweight audio classifier trained on distress-sound detection. A
  general vision-language model would only be invoked as a secondary
  step to describe an already-flagged anomaly in plain language.

In short: this prototype uses a large language model to demonstrate the
interaction and explanation pattern quickly, alongside two real
deterministic clinical scores that need no AI at all. The target
production architecture replaces the AI-scored core with trained,
validated, purpose-built models, and keeps a language model, if at
all, only for natural-language explanation, not the underlying
decision.


## Architecture and path to production

The prototype intentionally keeps everything client-side for demo
portability. A real deployment would look like:

```
Kiosk / nurse tablet --> Intake API --> Rule Engine (deterministic, on-prem)
                                    --> Acuity Service (LLM + fallback heuristic, behind auth)
                                    --> EHR integration (HL7 FHIR)
Waiting-room CCTV/mics --> Edge CV/audio inference --> Ambient Sentinel Service --> Nurse alert queue
Nurse review UI <-------------------------------------------------------------------------------|
                                    --> Outcome logging --> Nightly retraining / shadow-mode validation
```

Key production additions not in this prototype:

- A lightweight backend to hold the AI service access key securely -
  never exposed client-side in production.
- HL7 FHIR integration for EHR history pull.
- Real computer-vision and audio models for Ambient Sentinel, running
  at the edge rather than uploading video to the cloud, with strictly
  aggregate-signal retention and no facial recognition.
- Clinical governance sign-off and shadow-mode validation against real
  outcomes before any model update ships. See the
  [Business Proposal](docs/BUSINESS_PROPOSAL.md) for the phased
  rollout plan.
- Role-based access control, audit logging, and HIPAA/DPDP-aligned
  data handling throughout.


## Scalability

- Stateless scoring service: the AI and heuristic scoring layer takes
  structured input and returns structured output with no session
  state, so it scales the same way any stateless microservice does -
  additional emergency departments are additional API consumers, not
  additional infrastructure classes.
- Zero new hardware for Ambient Sentinel: because it is designed to
  run on cameras and microphones hospitals already operate, marginal
  deployment cost per additional site is software integration, not
  procurement.
- Model-agnostic scoring interface: the acuity-scoring call is a
  structured-input, structured-output interface, not a hard dependency
  on one model vendor, so it can be swapped for a fine-tuned in-house
  clinical model as volume and validation data grow.
- Phased rollout per site, from shadow-mode through advisory use,
  Sentinel pilot, and full scale, means each new hospital's onboarding
  risk is bounded and repeatable rather than a bespoke project.


## Impact

- Directly targets the costliest failure mode in emergency department
  triage - under-triage of critical patients - with a second, tireless
  read that does not fatigue across a shift.
- Closes the specific, commonly overlooked gap between triage and bed,
  where a deteriorating patient can currently go unnoticed.
- Explainable-by-design scoring, drivers and rationale rather than a
  bare number, is intended to build clinician trust and adoption
  rather than being a compliance checkbox.
- Confidence Fusion is a concrete mechanism for keeping a human in the
  loop precisely at the moments of highest uncertainty, rather than a
  generic human-in-the-loop claim.


## Troubleshooting and FAQ

**Q: What does the camera actually measure, and how?**

**A:** By default, the bounding boxes and the four Ambient Sentinel
gauges are simulated for demonstration and do not measure anything
real. The optional "Enable camera-based analysis" mode is real: it
sends an actual photo to the AI service and asks it to describe only
observable, non-diagnostic cues, such as posture or apparent distress.
It does not measure vitals numerically from the image.

**Q: How is the pain score measured?**

**A:** It is not measured by a device. The default is the patient's own
self-reported 0-10 rating, standard emergency-department practice. For
patients who cannot self-report, the "Patient can't self-report" toggle
switches to the FLACC observational scale, described in
[Solution overview](#solution-overview).

**Q: What are NEWS2 and qSOFA?**

**A:** NEWS2 (National Early Warning Score 2) is a published clinical
scoring tool that scores six vital signs on a 0-3 scale each, summed
into a Low, Medium, or High deterioration-risk band. qSOFA (quick
Sequential Organ Failure Assessment) is a fast bedside sepsis-risk
check based on three criteria. Both are implemented from their real
published thresholds, not approximated.

**Q: What is Surge Mode, and why does it exist?**

**A:** It switches every patient's scoring to the fast, deterministic
rule engine, skipping the AI call. During a mass-casualty event or
extreme patient volume, a per-patient AI call does not scale, and
model behavior tends to degrade under exactly the unusual conditions a
surge creates - a fast, predictable rule engine is more trustworthy
when things are chaotic.

**Q: What is Resus Auto-Trigger Override for?**

**A:** It lets a nurse force a patient straight to ESI 1 regardless of
what the calculated score says, for cases where clinical judgment
catches something the form or the AI did not. It exists so the tool
can never be a bottleneck between a nurse and an emergency action.

**Q: What are the names of ESI levels 1 through 5?**

**A:** 1: Resuscitation. 2: Emergent. 3: Urgent. 4: Less urgent. 5:
Non-urgent.

**Q: The camera or microphone will not turn on. What do I do?**

**A:** Camera-based analysis requires the browser to have been granted
camera permission for the page. If access is blocked or denied, the
prototype remains fully usable through the "Capture / upload photo"
and "Quick simulate" alternatives, which do not require a camera.

**Q: AI scoring keeps falling back to the offline heuristic. Why?**

**A:** Outside of a sandboxed preview environment, the browser's direct
call to the AI service needs an access key. Open Settings and enter a
key to enable live scoring; without one, the fallback path is expected
behavior, not a bug, and is always disclosed in the interface.


## Known limitations

- The Ambient Sentinel bounding boxes and metric gauges in the default
  (no-camera) view are simulated for demonstration - randomized jitter
  and scripted responses to an active alert, not real computer-vision
  output. The camera-based mode sends a real frame for analysis, but
  still analyzes single frames in isolation rather than a continuous
  feed compared against a stored baseline.
- The 20-second live-monitoring interval is a demo-speed compression;
  a real deployment would sample every few minutes, not seconds, and
  would run on dedicated CCTV infrastructure rather than a user's own
  webcam.
- AI scoring and vision calls are made directly from the browser,
  optionally using a user-supplied access key, for demo simplicity. A
  production system must never take an access key from the browser and
  would route these calls through an authenticated backend instead.
- The Bed Board is a simple in-memory occupancy tracker for this demo;
  it does not integrate with a real hospital bed-management or
  admit-discharge-transfer system.
- No real patient data, EHR integration, or clinical validation has
  been performed. ESI outputs and photo or frame observations from
  this prototype are illustrative only and are not clinically
  validated.
- The offline heuristic fallback is a simplified, illustrative
  approximation of NEWS2-style risk banding, not a certified clinical
  scoring tool, and is not itself a machine learning model. NEWS2 and
  qSOFA themselves are real published clinical formulas, correctly
  implemented from their standard point thresholds, including using
  the clinically correct GCS below 15 ("not fully alert") threshold
  for the altered-mentation component of both scores, distinct from
  the narrower GCS below 9 threshold used separately by the red-flag
  rule engine for airway-protection-level concern.
- FLACC is still an observed, somewhat subjective clinical judgment
  call by the nurse, not an objective sensor reading. Other
  observational pain tools, such as facial-grimace scales for older
  non-verbal patients or CPOT for sedated ICU-level patients, are not
  implemented.
- Nurse attribution is tracked in-memory for the current browser
  session only, tied to a free-text name - there is no login,
  authentication, or persistent staff directory behind it.
- Patient Records is an in-memory record that exists only for the
  current browser tab's session and disappears on refresh. Photos and
  ID documents are held as unencrypted data in browser memory, never
  persisted or transmitted anywhere. A production patient database
  would need encryption at rest, access controls, audit logging, and
  retention-policy compliance for this kind of identity data.


## Repository structure

```
/
|-- index.html                Primary prototype: open directly in a browser
|-- classic-prototype.html    Earlier, simpler build of the same logic
|-- README.md                 This document
`-- docs/
    `-- BUSINESS_PROPOSAL.md  Problem framing, business case, roadmap, risks
```


## Maintainers

- Team: mawandiaarchit
- Challenge: Accenture Innovation Challenge 2026, Problem Statement 2
